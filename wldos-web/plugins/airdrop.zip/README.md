# 脚本引擎插件 (Airdrop Plugin)

## 概述

脚本引擎是一个专为WLDOS系统设计的批量自动化执行脚本的插件模块。该插件基于WLDOS的hook机制实现，提供了完整的脚本任务管理功能，包括任务创建、模板管理、批量执行、队列调度等核心功能。

## 功能特性

### 🎯 核心功能
- **批量任务管理**: 创建、查看、管理脚本任务，支持创建、编辑、删除自动化任务
- **脚本执行引擎**: 支持JavaScript、Python、Shell等多种脚本类型
- **模板系统**: 提供可复用的任务模板
- **队列调度**: 支持并发执行、任务间隔、错误重试等配置
- **执行记录**: 完整的任务执行历史记录
- **附带动作**: 支持在任务执行前后执行附加操作
- **数据监控**: 任务执行过程中的数据监控和告警
- **自动更新**: 支持自动更新脚本和模板
- **权限管理**: 支持基于权限的管理
- **多语言支持**: 支持多语言
- **国际化支持**: 支持国际化
- **兼容性**: 兼容WLDOS系统
- **稳定性**: 稳定性高
- **安全性**: 安全性高
- **性能**: 性能高
- **易用性**: 易用性高
- **可扩展性**: 可扩展性高
- **可维护性**: 可维护性高
- **可移植性**: 可移植性高
- **可测试性**: 可测试性高
- **可重用性**: 可重用性高
- **可移植性**: 可移植性高
- **可移植性**: 可移植性高
- **可移植性**: 可移植性高
- **可移植性**: 可移植性高
- 完整的UI界面：基于React和Ant Design的用户界面

### 🔧 附带动作
- **推特绑定**: 自动绑定Twitter账号
- **自动完成**: 自动完成任务流程
- **自动验证**: 自动验证身份信息
- **自动claim**: 自动领取奖励
- **多次claim**: 支持多次领取功能
- **自定义RPC**: 使用自定义RPC节点
- **随机答案**: 随机选择答案

### 📊 队列设置
- **并发数**: 控制同时执行的任务数量
- **任务间隔**: 设置任务间的执行间隔
- **报错重试**: 配置失败重试次数
- **队列重复**: 支持队列重复执行

### 🏗️ 系统集成
- **数据库管理**: 由系统统一管理插件数据表
- **权限管理**: 由系统统一管理插件权限
- **菜单管理**: 由系统统一管理插件菜单
- **UI扩展管理**: 由系统统一管理插件UI扩展注册
- **生命周期**: 插件只需关注业务逻辑，系统负责资源管理

## WLDOS Hook机制

### Hook类型
- **HANDLER**: 处理型hook，返回处理结果
- **INVOKE**: 调用型hook，执行特定操作

### 扩展点定义
```json
{
  "extName": "airdrop.task.execute",
  "type": "HANDLER",
  "priority": 10,
  "numArgs": 2,
  "description": "执行脚本任务",
  "method": "executeAirdropTask"
}
```
## 目录结构
```
airdrop/
├── src/
│   ├── main/
│   │   ├── java/                    # Java源代码
│   │   └── resources/
│   │       ├── ui/                  # UI目录
│   │       │   ├── index.js         # UI入口文件
│   │       │   ├── extensions.json  # 扩展配置文件
│   │       │   ├── package.json     # 依赖管理
│   │       │   ├── webpack.config.js # 构建配置
│   │       │   ├── README.md        # UI说明文档
│   │       │   └── dist/            # 构建输出目录
│   │       ├── plugin.json          # 插件配置
│   │       ├── application.yml      # 应用配置
│   │       └── hooks.json           # Hook配置
│   └── assembly/
│       └── package.xml              # 打包配置
├── pom.xml                          # Maven配置
├── build-ui.sh                      # Linux/Mac构建脚本
├── build-ui.bat                     # Windows构建脚本
└── README.md                        # 说明文档
```

### 支持的扩展点
1. **airdrop.task.execute** - 执行脚本任务
2. **airdrop.task.status** - 查询任务状态
3. **airdrop.batch.execute** - 批量执行任务
4. **airdrop.script.validate** - 验证脚本内容
5. **airdrop.template.load** - 加载任务模板
6. **airdrop.queue.status** - 查询队列状态
7. **airdrop.plugin.init** - 插件初始化
8. **airdrop.plugin.cleanup** - 插件清理
9. **menu.register** - 注册菜单

## 使用说明
### 1. 构建UI

在构建插件之前，需要先构建UI：

**Linux/Mac:**
```bash
chmod +x build-ui.sh
./build-ui.sh
```

**Windows:**
```cmd
build-ui.bat
```

### 2. 构建插件

```bash
mvn clean package
```

构建完成后，会在 `target/` 目录下生成 `airdrop.zip` 文件。

### 3. 安装插件

将生成的 `airdrop.zip` 文件上传到WLDOS系统的插件管理页面进行安装。

### 4. 启用插件

在插件管理页面启用插件后，系统会自动：
- 注册插件的菜单和路由
- 加载插件的UI组件
- 集成到主系统的菜单中

## API文档

### 插件配置

`plugin.json` 文件定义了插件的基本信息：

```json
{
  "pluginCode": "airdrop",
  "name": "脚本引擎",
  "version": "1.0.0",
  "description": "自动化脚本任务管理插件",
  "mainClass": "com.wldos.plugin.airdrop.loader.PluginLoader",
  "author": "WLDOS Team"
}
```

### 扩展配置

`ui/extensions.json` 文件定义了插件的菜单和路由扩展：

```json
{
  "extensions": [
    {
      "id": "airdrop-scheduler",
      "name": "自动化调度器",
      "path": "/airdrop/scheduler",
      "icon": "ScheduleOutlined",
      "component": "AirdropLayout",
      "sort": 100,
      "permissions": ["airdrop:scheduler:view"]
    }
  ]
}
```

## 权限配置

插件支持以下权限：

- `airdrop:scheduler:view` - 查看调度器
- `airdrop:tasks:view` - 查看任务管理
- `airdrop:templates:view` - 查看模板管理
- `airdrop:execution:view` - 查看执行记录

## 开发说明

### UI开发

1. 进入UI目录：`cd src/main/ui`
2. 安装依赖：`yarn install`
3. 开发模式：`yarn dev` 或 `yarn dev:standalone`
4. 构建生产版本：`yarn build`

**注意**: 插件采用JavaScript模块构建方式，构建输出为 `dist/index.js` 文件。详细说明请参考 [UI构建说明.md](UI构建说明.md)

### 后端开发

1. 修改Java源代码
2. 更新插件配置
3. 重新构建插件

## 注意事项

1. UI构建必须在插件打包之前完成
2. 确保 `extensions.json` 中的组件名称与 `index.js` 中导出的组件名称一致
3. 权限配置要与后端权限系统保持一致
4. 构建后的UI文件会自动包含在插件包中
5. 插件采用JavaScript模块构建，依赖React、ReactDOM、Ant Design等外部库（由主系统提供）
6. UI构建输出为 `dist/index.js` 单个文件，采用UMD格式

## 更新日志

### [1.0.0] - 2024-01-01
- 初始版本发布
- 基础功能实现
- 完整UI界面
- 插件打包配置
