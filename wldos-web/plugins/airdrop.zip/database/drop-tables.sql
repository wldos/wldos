-- 插件测试表删除脚本
-- 按照依赖关系顺序删除表，避免外键约束问题

DROP TABLE IF EXISTS {t:execution};

DROP TABLE IF EXISTS {t:records};

DROP TABLE IF EXISTS {t:task};

DROP TABLE IF EXISTS {t:template};

DROP TABLE IF EXISTS {t:queue};

DROP TABLE IF EXISTS {t:config};
