/* 插件测试表创建脚本 */
/* 表名必须以 plugin_airdrop_ 开头，确保不会与系统表冲突 */

/* 逻辑表名使用占位符 {t:name} */
CREATE TABLE IF NOT EXISTS {t:config} (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    config_type VARCHAR(50) NOT NULL COMMENT '配置类型',
    config_key VARCHAR(100) NOT NULL COMMENT '配置键',
    config_value TEXT COMMENT '配置值',
    config_desc VARCHAR(500) COMMENT '配置描述',
    is_enabled TINYINT DEFAULT 1 COMMENT '是否启用',
    sort_order INT DEFAULT 0 COMMENT '排序',
    create_by BIGINT COMMENT '创建人ID',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    create_ip VARCHAR(50) COMMENT '创建IP',
    update_by BIGINT COMMENT '更新人ID',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    update_ip VARCHAR(50) COMMENT '更新IP',
    delete_flag VARCHAR(10) DEFAULT 'N' COMMENT '删除标志',
    is_valid VARCHAR(10) DEFAULT 'Y' COMMENT '是否有效',
    versions INT DEFAULT 1 COMMENT '乐观锁版本号',
    INDEX idx_config_type (config_type),
    INDEX idx_config_key (config_key),
    INDEX idx_is_enabled (is_enabled),
    UNIQUE KEY uk_type_key (config_type, config_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='脚本配置表';

CREATE TABLE IF NOT EXISTS {t:task} (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    task_name VARCHAR(255) NOT NULL COMMENT '任务名称',
    task_type VARCHAR(50) NOT NULL COMMENT '任务类型',
    script_content TEXT COMMENT '脚本内容',
    script_type VARCHAR(20) DEFAULT 'javascript' COMMENT '脚本类型',
    template_id BIGINT COMMENT '模板ID',
    status VARCHAR(20) DEFAULT 'pending' COMMENT '任务状态',
    priority INT DEFAULT 0 COMMENT '优先级',
    max_retries INT DEFAULT 3 COMMENT '最大重试次数',
    retry_interval INT DEFAULT 60 COMMENT '重试间隔(秒)',
    concurrent_limit INT DEFAULT 1 COMMENT '并发限制',
    execution_timeout INT DEFAULT 3600 COMMENT '执行超时时间(秒)',
    start_time DATETIME COMMENT '开始时间',
    end_time DATETIME COMMENT '结束时间',
    last_execution_time DATETIME COMMENT '最后执行时间',
    execution_count INT DEFAULT 0 COMMENT '执行次数',
    success_count INT DEFAULT 0 COMMENT '成功次数',
    failure_count INT DEFAULT 0 COMMENT '失败次数',
    config_json TEXT COMMENT '配置JSON',
    description TEXT COMMENT '任务描述',
    create_by BIGINT COMMENT '创建人ID',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    create_ip VARCHAR(50) COMMENT '创建IP',
    update_by BIGINT COMMENT '更新人ID',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    update_ip VARCHAR(50) COMMENT '更新IP',
    delete_flag VARCHAR(10) DEFAULT 'N' COMMENT '删除标志',
    is_valid VARCHAR(10) DEFAULT 'Y' COMMENT '是否有效',
    versions INT DEFAULT 1 COMMENT '乐观锁版本号',
    INDEX idx_task_name (task_name),
    INDEX idx_task_type (task_type),
    INDEX idx_status (status),
    INDEX idx_create_time (create_time),
    INDEX idx_template_id (template_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='脚本任务表';

CREATE TABLE IF NOT EXISTS {t:template} (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    template_name VARCHAR(255) NOT NULL COMMENT '模板名称',
    template_type VARCHAR(50) NOT NULL COMMENT '模板类型',
    script_content TEXT COMMENT '脚本内容',
    script_type VARCHAR(20) DEFAULT 'javascript' COMMENT '脚本类型',
    config_json TEXT COMMENT '配置JSON',
    description TEXT COMMENT '模板描述',
    version VARCHAR(20) DEFAULT '1.0.0' COMMENT '版本号',
    is_public TINYINT DEFAULT 0 COMMENT '是否公开',
    usage_count INT DEFAULT 0 COMMENT '使用次数',
    create_by BIGINT COMMENT '创建人ID',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    create_ip VARCHAR(50) COMMENT '创建IP',
    update_by BIGINT COMMENT '更新人ID',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    update_ip VARCHAR(50) COMMENT '更新IP',
    delete_flag VARCHAR(10) DEFAULT 'N' COMMENT '删除标志',
    is_valid VARCHAR(10) DEFAULT 'Y' COMMENT '是否有效',
    versions INT DEFAULT 1 COMMENT '乐观锁版本号',
    INDEX idx_template_name (template_name),
    INDEX idx_template_type (template_type),
    INDEX idx_is_public (is_public),
    INDEX idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='脚本模板表';

CREATE TABLE IF NOT EXISTS {t:execution} (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    task_id BIGINT NOT NULL COMMENT '任务ID',
    execution_id VARCHAR(100) NOT NULL COMMENT '执行ID',
    status VARCHAR(20) NOT NULL COMMENT '执行状态',
    start_time DATETIME NOT NULL COMMENT '开始时间',
    end_time DATETIME COMMENT '结束时间',
    duration INT COMMENT '执行时长(秒)',
    result_data TEXT COMMENT '执行结果数据',
    error_message TEXT COMMENT '错误信息',
    retry_count INT DEFAULT 0 COMMENT '重试次数',
    log_content TEXT COMMENT '日志内容',
    create_by BIGINT COMMENT '创建人ID',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    create_ip VARCHAR(50) COMMENT '创建IP',
    update_by BIGINT COMMENT '更新人ID',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    update_ip VARCHAR(50) COMMENT '更新IP',
    delete_flag VARCHAR(10) DEFAULT 'N' COMMENT '删除标志',
    is_valid VARCHAR(10) DEFAULT 'Y' COMMENT '是否有效',
    versions INT DEFAULT 1 COMMENT '乐观锁版本号',
    INDEX idx_task_id (task_id),
    INDEX idx_execution_id (execution_id),
    INDEX idx_status (status),
    INDEX idx_start_time (start_time),
    INDEX idx_task_status (task_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='执行记录表';

CREATE TABLE IF NOT EXISTS {t:queue} (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    queue_name VARCHAR(100) NOT NULL COMMENT '队列名称',
    max_concurrent INT DEFAULT 5 COMMENT '最大并发数',
    task_interval INT DEFAULT 10 COMMENT '任务间隔(秒)',
    retry_policy VARCHAR(50) DEFAULT 'fixed' COMMENT '重试策略',
    max_retries INT DEFAULT 3 COMMENT '最大重试次数',
    retry_interval INT DEFAULT 60 COMMENT '重试间隔(秒)',
    timeout_policy VARCHAR(50) DEFAULT 'abort' COMMENT '超时策略',
    execution_timeout INT DEFAULT 3600 COMMENT '执行超时时间(秒)',
    is_enabled TINYINT DEFAULT 1 COMMENT '是否启用',
    config_json TEXT COMMENT '配置JSON',
    description TEXT COMMENT '队列描述',
    create_by BIGINT COMMENT '创建人ID',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    create_ip VARCHAR(50) COMMENT '创建IP',
    update_by BIGINT COMMENT '更新人ID',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    update_ip VARCHAR(50) COMMENT '更新IP',
    delete_flag VARCHAR(10) DEFAULT 'N' COMMENT '删除标志',
    is_valid VARCHAR(10) DEFAULT 'Y' COMMENT '是否有效',
    versions INT DEFAULT 1 COMMENT '乐观锁版本号',
    INDEX idx_queue_name (queue_name),
    INDEX idx_is_enabled (is_enabled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='队列配置表';

/* 插入默认队列配置 */
INSERT INTO {t:queue} (queue_name, max_concurrent, task_interval, description, delete_flag, is_valid) 
VALUES ('default', 5, 10, '默认队列配置', 'normal', '1')
ON DUPLICATE KEY UPDATE update_time = CURRENT_TIMESTAMP;

/* 插入默认模板 */
INSERT INTO {t:template} (template_name, template_type, script_content, script_type, description, is_public, delete_flag, is_valid) 
VALUES (
    '标准脚本模板',
    'standard', 
    'console.log("执行标准脚本任务"); return { success: true, message: "脚本任务执行成功" };',
    'javascript', 
    '适用于大多数脚本场景的标准模板',
    1,
    'normal',
    '1'
) ON DUPLICATE KEY UPDATE update_time = CURRENT_TIMESTAMP;
