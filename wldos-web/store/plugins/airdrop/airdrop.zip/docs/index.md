# WLDOS 脚本插件

## 简介
WLDOS 脚本插件是一个功能完整的脚本任务管理插件，提供脚本任务的创建、模板管理、执行队列和结果统计等功能。

## 功能特性
- **脚本任务管理**：创建、编辑、删除脚本任务
- **模板系统**：支持多种脚本模板，快速创建标准化任务
- **执行队列**：异步执行脚本任务，支持批量处理
- **结果统计**：实时统计脚本执行结果和成功率
- **权限控制**：基于角色的权限管理，确保操作安全
- **UI界面**：完整的Web界面，支持可视化操作

## 使用说明
1. **安装插件**：通过插件管理器安装脚本插件
2. **配置参数**：设置脚本相关的基础参数
3. **创建模板**：根据业务需求创建脚本模板
4. **创建任务**：基于模板创建具体的脚本任务
5. **执行监控**：监控任务执行状态和结果

## API文档

### 脚本任务管理
- `POST /api/airdrop/task` - 创建脚本任务
- `GET /api/airdrop/task/{id}` - 获取任务详情
- `PUT /api/airdrop/task/{id}` - 更新任务信息
- `DELETE /api/airdrop/task/{id}` - 删除任务
- `GET /api/airdrop/task/list` - 获取任务列表

### 模板管理
- `POST /api/airdrop/template` - 创建脚本模板
- `GET /api/airdrop/template/{id}` - 获取模板详情
- `PUT /api/airdrop/template/{id}` - 更新模板
- `DELETE /api/airdrop/template/{id}` - 删除模板
- `GET /api/airdrop/template/list` - 获取模板列表

### 执行管理
- `POST /api/airdrop/execute/{taskId}` - 执行脚本任务
- `GET /api/airdrop/execution/{id}` - 获取执行详情
- `GET /api/airdrop/execution/list` - 获取执行列表
- `GET /api/airdrop/queue/status` - 获取队列状态

## 权限说明
- `airdrop:task:view` - 查看脚本任务
- `airdrop:task:create` - 创建脚本任务
- `airdrop:task:edit` - 编辑脚本任务
- `airdrop:task:delete` - 删除脚本任务
- `airdrop:template:view` - 查看模板
- `airdrop:template:create` - 创建模板
- `airdrop:template:edit` - 编辑模板
- `airdrop:template:delete` - 删除模板
- `airdrop:execute:view` - 查看执行记录
- `airdrop:execute:run` - 执行脚本任务

## 配置说明
插件支持以下配置参数：
- `airdrop.max.concurrent.tasks` - 最大并发任务数（默认：10）
- `airdrop.queue.capacity` - 队列容量（默认：1000）
- `airdrop.retry.max.attempts` - 最大重试次数（默认：3）
- `airdrop.timeout.seconds` - 任务超时时间（默认：300秒）

## 故障排除
1. **任务执行失败**：检查网络连接和权限配置
2. **队列阻塞**：检查并发限制和系统资源
3. **模板加载错误**：验证模板配置格式
4. **权限不足**：确认用户角色和权限分配

## 技术支持
如有问题，请联系技术支持团队或查看详细日志。
