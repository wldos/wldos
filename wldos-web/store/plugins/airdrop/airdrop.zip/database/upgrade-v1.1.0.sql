-- 插件升级脚本 v1.0.0 -> v1.1.0
-- 安全升级插件表结构，只操作插件自己的表

-- 1. 添加新字段到现有表
ALTER TABLE {t:task} 
ADD COLUMN priority INT DEFAULT 0 COMMENT '优先级' AFTER status,
ADD COLUMN max_retries INT DEFAULT 3 COMMENT '最大重试次数' AFTER priority,
ADD COLUMN retry_interval INT DEFAULT 60 COMMENT '重试间隔(秒)' AFTER max_retries;

-- 2. 创建新表
CREATE TABLE IF NOT EXISTS {t:records} (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    task_id BIGINT NOT NULL COMMENT '任务ID',
    recipient_address VARCHAR(100) NOT NULL COMMENT '接收地址',
    amount DECIMAL(18,8) NOT NULL COMMENT '脚本数量',
    status VARCHAR(20) DEFAULT 'PENDING' COMMENT '状态',
    tx_hash VARCHAR(100) COMMENT '交易哈希',
    block_number BIGINT COMMENT '区块号',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (task_id) REFERENCES {t:task}(id) ON DELETE CASCADE,
    INDEX idx_task_id (task_id),
    INDEX idx_recipient_address (recipient_address),
    INDEX idx_status (status),
    INDEX idx_tx_hash (tx_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='脚本记录表';

-- 3. 更新现有数据
UPDATE {t:task} 
SET priority = 0, max_retries = 3, retry_interval = 60 
WHERE priority IS NULL;

-- 4. 插入默认配置数据
INSERT INTO {t:queue} (queue_name, max_concurrent, task_interval, description) 
VALUES ('upgrade_default', 10, 5, '升级后的默认队列配置')
ON DUPLICATE KEY UPDATE update_time = CURRENT_TIMESTAMP;
